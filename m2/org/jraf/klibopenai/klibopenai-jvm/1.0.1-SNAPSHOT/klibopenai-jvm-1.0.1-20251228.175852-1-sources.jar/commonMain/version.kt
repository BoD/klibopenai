// Generated file. Do not edit!
package org.jraf.klibopenai
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.0.1-SNAPSHOT"
